Just run Downloader.bat, if you want to cancell the virus, just click on virusstoper.bat, but i added it because dilligaf, and it means
DO
I
LOOK
LIKE
I
GIVE
A
FU- nvm is it a dead meme or not bruh bcz i was abt to say it